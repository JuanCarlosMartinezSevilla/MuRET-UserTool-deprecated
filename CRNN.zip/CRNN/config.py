
class Config:
    img_height = 128
    num_channels = 3